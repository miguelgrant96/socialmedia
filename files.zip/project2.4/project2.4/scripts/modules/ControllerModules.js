angular.module('Login', ['ngRoute']);
angular.module('Register', ['ngRoute']);
angular.module('Feed', ['ngRoute']);
angular.module('Profile', ['ngRoute']);
angular.module('Options', ['ngRoute']);
angular.module('Privacy', ['ngRoute']);
angular.module('Logout', ['ngRoute']);